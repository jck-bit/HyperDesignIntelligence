import { z } from "zod";

export interface VoiceSettings {
  stability: number;
  similarityBoost: number;
  style: number;
  speakerBoost?: boolean;
}

export interface VoiceOption {
  id: string;
  name: string;
}

export class VoiceService {
  private audioContext: AudioContext | null = null;

  async initAudio(): Promise<void> {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
  }

  async synthesizeSpeech({ text, persona }: { 
    text: string; 
    persona?: string;
  }): Promise<void> {
    if (!text.trim()) return;

    try {
      if (!this.audioContext || this.audioContext.state !== 'running') {
        await this.initAudio();
      }

      const response = await fetch('/api/synthesize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          persona
        }),
      });

      if (!response.ok) {
        throw new Error(`Speech synthesis failed: ${response.status}`);
      }

      const arrayBuffer = await response.arrayBuffer();
      const audioBuffer = await this.audioContext!.decodeAudioData(arrayBuffer);
      const source = this.audioContext!.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.audioContext!.destination);
      source.start(0);

      return new Promise((resolve) => {
        source.onended = () => resolve();
      });
    } catch (error) {
      console.error('Error in speech synthesis:', error);
      throw error;
    }
  }

  async getAvailableVoices(): Promise<VoiceOption[]> {
    try {
      const response = await fetch('/api/voices');
      if (!response.ok) {
        throw new Error(`Failed to fetch voices: ${response.status}`);
      }
      const voices = await response.json();
      return voices.map((v: any) => ({
        id: v.voice_id,
        name: v.name
      }));
    } catch (error) {
      console.error('Error fetching voices:', error);
      return [];
    }
  }
}

export const voiceService = new VoiceService();