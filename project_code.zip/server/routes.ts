import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer from 'multer';
import { storage } from "./storage";
import { insertAgentSchema, insertDigitalTwinSchema } from "@shared/schema";
import { voiceService } from "./voice-service";
import { documentService } from "./document-service";
import { z } from "zod";
import { insertConversationSchema } from "@shared/schema";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

export function registerRoutes(app: Express): Server {
  const httpServer = createServer(app);
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  // Add initial digital twin agents
  (async () => {
    await storage.createAgent({
      name: "Albert Einstein",
      type: "Theoretical Physics",
      capabilities: ["Innovation", "Research", "Problem Solving"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Einstein",
      status: "active"
    });

    await storage.createAgent({
      name: "Elon Musk",
      type: "Tech Entrepreneur",
      capabilities: ["Innovation", "Strategic Thinking", "Product Development"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Musk",
      status: "active"
    });

    await storage.createAgent({
      name: "Emad Mostaque",
      type: "AI Innovator",
      capabilities: ["Artificial Intelligence", "Leadership", "Technical Vision"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Mostaque",
      status: "active"
    });

    await storage.createAgent({
      name: "Fei-Fei Li",
      type: "AI Research",
      capabilities: ["Artificial Intelligence", "Research", "Technical Vision"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Li",
      status: "active"
    });

    await storage.createAgent({
      name: "Leonardo da Vinci",
      type: "Renaissance Innovator",
      capabilities: ["Innovation", "Art", "Engineering"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=DaVinci",
      status: "active"
    });

    await storage.createAgent({
      name: "Steve Jobs",
      type: "Tech Visionary",
      capabilities: ["Innovation", "Product Development", "Design"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jobs",
      status: "active"
    });

    await storage.createAgent({
      name: "Walt Disney",
      type: "Creative Visionary",
      capabilities: ["Creativity", "Innovation", "Storytelling"],
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Disney",
      status: "active"
    });
  })();

  // WebSocket connection handling
  wss.on("connection", (ws) => {
    console.log("New WebSocket connection established");

    const broadcast = () => {
      if (ws.readyState === WebSocket.OPEN) {
        storage.getAgents().then((agents) => {
          ws.send(JSON.stringify({ type: "agents_update", data: agents }));
        });
      }
    };

    // Send initial data
    broadcast();

    ws.on("message", async (message) => {
      const data = JSON.parse(message.toString());

      if (data.type === "update_status") {
        await storage.updateAgentStatus(data.agentId, data.status);
        broadcast();
      } else if (data.type === "update_metrics") {
        await storage.updateAgentMetrics(data.agentId, data.metrics);
        broadcast();
      }
    });

    ws.on("error", console.error);
  });

  // Document upload endpoint
  app.post("/api/upload-twin-document", upload.single('document'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No document provided' });
      }

      const { name } = req.body;
      if (!name) {
        return res.status(400).json({ error: 'Twin name is required' });
      }

      const content = await documentService.processWordDocument(req.file);
      await documentService.createDigitalTwin(content, name);

      res.json({ message: 'Digital twin created successfully' });
    } catch (error) {
      console.error('Error processing document:', error);
      res.status(500).json({ error: 'Failed to process document' });
    }
  });

  // Existing routes...
  app.post("/api/synthesize", async (req, res) => {
    try {
      const { text, persona } = req.body;
      console.log('Synthesis request:', { text, persona });

      const audioBuffer = await voiceService.synthesizeSpeech({
        text,
        persona,
        modelId: "eleven_monolingual_v1"
      });

      res.set({
        'Content-Type': 'audio/mpeg',
        'Transfer-Encoding': 'chunked'
      });
      res.send(audioBuffer);
    } catch (error) {
      console.error('Speech synthesis error:', error);
      res.status(500).json({ error: 'Speech synthesis failed' });
    }
  });

  // Get available voices endpoint
  app.get("/api/voices", async (_req, res) => {
    try {
      const voices = await voiceService.getVoices();
      res.json(voices);
    } catch (error) {
      console.error('Error fetching voices:', error);
      res.status(500).json({ error: 'Failed to fetch voices' });
    }
  });

  // Digital Twins endpoints
  app.get("/api/digital-twins", async (_req, res) => {
    const twins = await storage.getDigitalTwins();
    res.json(twins);
  });

  app.post("/api/digital-twins", async (req, res) => {
    const result = insertDigitalTwinSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const twin = await storage.createDigitalTwin(result.data);
    res.json(twin);
  });

  // REST endpoints
  app.get("/api/agents", async (_req, res) => {
    const agents = await storage.getAgents();
    res.json(agents);
  });

  app.post("/api/agents", async (req, res) => {
    const result = insertAgentSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const agent = await storage.createAgent(result.data);
    res.json(agent);
  });

  // Conversation endpoints
  app.get("/api/conversations", async (_req, res) => {
    const conversations = await storage.getConversations();
    res.json(conversations);
  });

  app.post("/api/conversations", async (req, res) => {
    const result = insertConversationSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    const conversation = await storage.createConversation(result.data);
    res.json(conversation);
  });

  app.get("/api/conversations/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid conversation ID" });
    }

    const conversation = await storage.getConversation(id);
    if (!conversation) {
      return res.status(404).json({ error: "Conversation not found" });
    }

    res.json(conversation);
  });

  app.get("/api/conversations/participant/:name", async (req, res) => {
    const conversations = await storage.getConversationsByParticipant(req.params.name);
    res.json(conversations);
  });

  return httpServer;
}