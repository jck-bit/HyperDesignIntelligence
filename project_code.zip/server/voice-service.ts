import { z } from "zod";

export class VoiceService {
  private apiKey: string;
  private useElevenLabs: boolean = true;
  private lastCallTimestamp: number = 0;
  private rateLimitDelay: number = 1000; // 1 second between calls

  constructor() {
    this.apiKey = process.env.ELEVENLABS_API_KEY || '';
    if (!this.apiKey) {
      console.warn("ElevenLabs API key not found");
      this.useElevenLabs = false;
    } else {
      console.log("ElevenLabs service initialized with API key length:", this.apiKey.length);

      // Log first and last character of key for debugging (safely)
      if (this.apiKey.length > 2) {
        console.log("Key starts with:", this.apiKey[0], "ends with:", this.apiKey[this.apiKey.length - 1]);
      }
    }
  }

  async synthesizeSpeech({ text, persona }: { 
    text: string; 
    persona?: string;
  }): Promise<Buffer> {
    if (!this.useElevenLabs || !this.apiKey) {
      throw new Error('ElevenLabs API key required for voice synthesis');
    }

    // Limit text length to stay within quota
    const maxChars = 150;
    const truncatedText = text.length > maxChars ? 
      text.substring(0, maxChars) + "..." : 
      text;

    try {
      // Add delay if needed
      const timeSinceLastCall = Date.now() - this.lastCallTimestamp;
      if (timeSinceLastCall < this.rateLimitDelay) {
        await new Promise(r => setTimeout(r, this.rateLimitDelay - timeSinceLastCall));
      }

      // Customize voice settings based on persona
      const isLeonardo = persona?.toLowerCase().includes('leonardo');
      const personalizedVoiceId = isLeonardo
        ? "ThT5KcBeYPX3keUQqHPh"  // Leonardo's voice
        : "AZnzlk1XvdvUeBnXmlld"; // Jobs' voice

      // Voice settings optimized for each persona
      const voiceSettings = {
        stability: isLeonardo ? 0.8 : 0.67,
        similarity_boost: isLeonardo ? 0.80 : 0.85,
        style: isLeonardo ? 0.35 : 0.65,
        use_speaker_boost: true
      };

      const requestPayload = {
        text: truncatedText,
        model_id: "eleven_monolingual_v1",
        voice_settings: voiceSettings
      };

      // Log request details
      console.log('Voice synthesis request:', {
        persona,
        voiceId: personalizedVoiceId,
        textLength: truncatedText.length,
        settings: voiceSettings,
        apiKeyPresent: !!this.apiKey,
        apiKeyLength: this.apiKey.length,
        requestUrl: `https://api.elevenlabs.io/v1/text-to-speech/${personalizedVoiceId}`
      });

      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${personalizedVoiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey
        },
        body: JSON.stringify(requestPayload)
      });

      // Log full response details for debugging
      console.log('API Response Headers:', {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries())
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('ElevenLabs API error:', {
          status: response.status,
          statusText: response.statusText,
          errorBody: errorText,
          headers: Object.fromEntries(response.headers.entries())
        });
        throw new Error(`Speech synthesis failed: ${response.status} - ${errorText}`);
      }

      this.lastCallTimestamp = Date.now();
      const arrayBuffer = await response.arrayBuffer();
      console.log('Voice synthesis successful:', {
        persona,
        audioSize: arrayBuffer.byteLength,
        timestamp: new Date().toISOString()
      });
      return Buffer.from(arrayBuffer);
    } catch (error) {
      console.error('Error in speech synthesis:', {
        error: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : undefined,
        persona,
        textLength: truncatedText.length
      });
      throw error;
    }
  }

  async getVoices() {
    if (!this.useElevenLabs) {
      return [{ voice_id: "fallback", name: "Web Speech API" }];
    }

    try {
      console.log('Fetching voices from ElevenLabs API...');
      console.log('API Key Debug:', {
        length: this.apiKey.length,
        isString: typeof this.apiKey === 'string',
        isEmpty: !this.apiKey,
        firstChar: this.apiKey[0],
        lastChar: this.apiKey[this.apiKey.length - 1]
      });

      const response = await fetch('https://api.elevenlabs.io/v1/voices', {
        headers: {
          'Accept': 'application/json',
          'xi-api-key': this.apiKey
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Error fetching voices:', {
          status: response.status,
          statusText: response.statusText,
          errorBody: errorText
        });
        throw new Error('Failed to fetch ElevenLabs voices');
      }

      const data = await response.json();
      console.log('Successfully fetched voices:', {
        count: data.voices?.length || 0,
        timestamp: new Date().toISOString()
      });

      return data.voices.map((v: any) => ({
        voice_id: v.voice_id,
        name: v.name
      }));
    } catch (error) {
      console.error('Error fetching voices:', error);
      throw error;
    }
  }
}

export const voiceService = new VoiceService();